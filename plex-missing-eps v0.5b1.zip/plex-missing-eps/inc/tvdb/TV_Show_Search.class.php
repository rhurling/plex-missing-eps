<?php

	/**
	 * TV shows class, basic searching functionality
	 * 
	 * @package PHP::TVDB
	 * @author Ryan Doherty <ryan@ryandoherty.com>
	 */

	class TV_Show_Search extends TVDB {

	
	
		public function __construct() {
			parent::__construct();
		}
		
	}